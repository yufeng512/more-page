<template>
  <div
    class="points-edit-container"
    v-loading="isLoading"
    :element-loading-text="$t('loading')"
    element-loading-spinner="el-icon-loading"
  >
    <template v-if="segmentData">
      <!-- 条件面板 -->
      <div class="has-background-white condition-panel">
        <a-condition-panel
          :data="segmentData"
          :max-level="5"
          ref="conditionPanel"
          @onError="onError"
        ></a-condition-panel>
      </div>
      <!-- end -->
      <!-- 表单区 -->
      <div class="has-background-white field-panel">
        <div class="title">规则基础信息</div>
        <el-form ref="forms" :model="formData" :rules="rules" label-width="100px">
          <el-row>
            <!-- 规则名称 -->
            <el-col :xs="24" :sm="8" :md="8">
              <el-form-item prop="ruleName" :label="_labelLanguageHandler('ruleName')">
                <el-input
                  v-model.trim="formData.ruleName"
                  :placeholder="_typeLanguageHandler(1, 'ruleName')"
                  clearable
                ></el-input>
              </el-form-item>
            </el-col>
            <!-- 类型 -->
            <el-col :xs="24" :sm="8" :md="8">
              <el-form-item prop="ruleTypeSelect" :label="_labelLanguageHandler('ruleType')">
                <el-select
                  v-model="_ruleTypeSelect"
                  :placeholder="_typeLanguageHandler(0, 'ruleType')"
                  clearable
                >
                  <el-option
                    v-for="(items, index) in formData.ruleTypeOption"
                    :key="'_'+index"
                    :value="items.value"
                    :label="items.text"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <!-- 有效期 -->
            <el-col :xs="24" :sm="8" :md="8">
              <el-form-item prop="rangeDate" :label="_labelLanguageHandler('rangeDate')">
                <el-date-picker
                  v-model="formData.rangeDate"
                  type="daterange"
                  value-format="yyyyMMdd"
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                ></el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <!-- 规则组 -->
            <el-col :xs="24" :sm="8" :md="8">
              <el-form-item prop="ruleGroup" :label="_labelLanguageHandler('ruleGroup')">
                <el-input
                  v-model.trim="formData.ruleGroup"
                  :placeholder="_typeLanguageHandler(1, 'ruleGroup')"
                  clearable
                ></el-input>
              </el-form-item>
            </el-col>
            <!-- 状态 -->
            <el-col :xs="24" :sm="8" :md="8">
              <el-form-item :label="_labelLanguageHandler('status')" prop="statusSelect">
                <el-select
                  v-model="_statusSelect"
                  :placeholder="_typeLanguageHandler(0, 'status')"
                  clearable
                >
                  <el-option
                    v-for="(items, index) in formData.statusOption"
                    :key="'_'+index"
                    :value="items.value"
                    :label="items.text"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <!-- 描述 -->
            <el-col :xs="24" :sm="8" :md="8">
              <el-form-item :label="_labelLanguageHandler('description')">
                <el-input
                  type="textarea"
                  v-model.trim="formData.description"
                  :autosize="{ minRows: 4, maxRows: 12}"
                  :placeholder="_typeLanguageHandler(1, 'description')"
                  clearable
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div class="has-background-white field-panel">
        <div class="title">积分及权益设置</div>
        <el-row>
          <el-col :span="1" class="add-control">
            <span @click="addPointsRow">+</span>
          </el-col>
          <el-col :span="23">
            <el-row class="tables">
              <el-col :span="4">权益名称</el-col>
              <el-col :span="4">积分依据</el-col>
              <el-col :span="2">运算符</el-col>
              <el-col :span="2">系数</el-col>
              <el-col :span="4">有效期类型</el-col>
              <el-col :span="2">有效期</el-col>
              <el-col :span="4">取舍规则</el-col>
              <el-col :span="2">冻结天数</el-col>
            </el-row>
            <el-form ref="forms2" :model="pointsRowCacheData">
              <el-row v-for="(rows, index) in jsonResultData" :key="'_'+index">
                <!-- 权益名称 -->
                <el-col :span="4" class="point-panel">
                  <el-form-item
                    label-width="0"
                    :prop="'jsonResult.'+index+'.groupId'"
                    :rules="{required: true, message: '此处不能为空', trigger: 'change'}"
                  >
                    <el-select
                      v-model="rows.groupId"
                      placeholder="选择权益名称"
                      @change="resultInfoHandler($event, index, 'parent')"
                      clearable
                    >
                      <el-option
                        v-for="(childs, index) in rows.SELECTDATA"
                        :key="'_'+index"
                        :disabled="childs.groupId == rows.groupId || _groupId.includes(childs.groupId)"
                        :value="childs.groupId"
                        :label="childs.groupName"
                      ></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <!-- 积分依据 -->
                <el-col :span="4" class="point-panel">
                  <el-form-item
                    label-width="0"
                    :prop="'jsonResult.'+index+'.fieldValue'"
                    :rules="{required: true, message: '此处不能为空', trigger: 'change'}"
                  >
                    <el-select
                      v-model="rows.fieldValue"
                      placeholder="选择积分依据"
                      @change="resultInfoHandler($event, index, 'child')"
                      clearable
                    >
                      <el-option
                        v-for="(childs, index) in rows.CUSTOM.conditions"
                        :key="'_'+index"
                        :value="childs.fieldValue"
                        :label="childs.fieldName"
                      ></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <!-- 运算符 -->
                <el-col :span="2" class="point-panel">
                  <el-form-item
                    label-width="0"
                    :prop="'jsonResult.'+index+'.operation'"
                    :rules="{required: true, message: '此处不能为空', trigger: 'change'}"
                  >
                    <el-select v-model="rows.operation" placeholder="选择运算符" clearable>
                      <el-option
                        v-for="(childs, index) in formData.operationSelect"
                        :key="'_'+index"
                        :value="childs.value"
                        :label="childs.text"
                      ></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <!-- 系数 -->
                <el-col :span="2" class="point-panel">
                  <el-form-item
                    label-width="0"
                    :prop="'jsonResult.'+index+'.ratioVal'"
                    :rules="[
                  {required: true, message: '此处不能为空', trigger: 'blur'},
                  { type:'number' , validator: _toValiDateNumber}
                  ]"
                  >
                    <el-input v-model.number="rows.ratioVal" placeholder="填写系数"></el-input>
                  </el-form-item>
                </el-col>
                <!-- 有效期类型 -->
                <el-col
                  :span="4"
                  :class="['point-panel', _validDateType(rows.CUSTOM.validDateType)]"
                >
                  <el-form-item label-width="0">
                    <el-input disabled v-model.trim="rows.CUSTOM.validDateTypeText"></el-input>
                  </el-form-item>
                </el-col>
                <!-- 有效期 -->
                <el-col :span="2" class="point-panel">
                  <el-form-item label-width="0">
                    <el-input disabled v-model.number="rows.CUSTOM.validDateVal"></el-input>
                  </el-form-item>
                </el-col>
                <!-- 取舍规则 -->
                <el-col :span="4" class="point-panel">
                  <el-form-item
                    label-width="0"
                    :prop="'jsonResult.'+index+'.roundType'"
                    :rules="{required: true, message: '此处不能为空', trigger: 'change'}"
                  >
                    <el-select v-model="rows.roundType" placeholder="选择取舍规则" clearable>
                      <el-option
                        v-for="(childs, index) in formData.roundTypeOptions"
                        :key="'_'+index"
                        :value="childs.value"
                        :label="childs.text"
                      ></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <!-- 冻结天数 -->
                <el-col :span="2">
                  <el-form-item
                    label-width="0"
                    :prop="'jsonResult.'+index+'.frozenDays'"
                    :rules="[
                  {required: true, message: '此处不能为空', trigger: 'blur'},
                  { type:'number' , validator: _toValiDateNumber}
                  ]"
                  >
                    <el-input v-model.number="rows.frozenDays" placeholder="填写冻结天数"></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
          </el-col>
        </el-row>
      </div>
      <div class="field-btn">
        <div class="confirm" @click="submitForm">确定</div>
        <div class="cancel" @click="$router.push('/rules/point')">取消</div>
      </div>
    </template>
  </div>
  <!-- end -->
</template>

<script>
import _ from "lodash";
import { aConditionPanel } from "@/components/ConditionPanel";
import CommonForm from "@/components/CommonForm";

import request from "@/utils/request.js";
import api from "./api.js";

export default {
  data() {
    return {
      formData: {
        // 积分规则id
        ruleId: "",
        // 规则类型
        ruleTypeSelect: "",
        ruleTypeOption: [],

        // 积分规则名称
        ruleName: "",
        // 有效期
        rangeDate: [],
        // 规则状态
        statusSelect: "",
        statusOption: [],

        // 积分规则分类
        ruleGroup: "",
        // 描述
        description: "",

        // 取舍规则
        roundTypeOptions: [],
        // 运算符
        operationSelect: [],
        // 系数
        ratioVal: ""
      },
      rules: {
        ruleName: [
          { required: true, message: "规则名称不能为空", trigger: "blur" },
          { max: 100, message: "请最多填写100个字符", trigger: "blur" }
        ],
        ruleTypeSelect: [
          { required: true, message: "类型不能为空", trigger: "change" }
        ],
        // statusSelect: [
        //   { required: true, message: "状态不能为空", trigger: "change" }
        // ],
        rangeDate: [
          { required: true, message: "有效期不能为空", trigger: "blur" }
        ],
        ruleGroup: [
          { required: true, message: "规则组不能为空", trigger: "blur" },
          { max: 100, message: "请最多填写100个字符", trigger: "blur" }
        ]
      },
      // 积分权益配置缓存
      pointsRowCacheData: {
        resultInfo: [],
        jsonResult: []
      },
      conditionInfo: [],
      segmentData: null,
      conditionList: [],
      isLoading: false
    };
  },
  methods: {
    request(o) {
      this.isLoading = true;
      return request(o)
        .then(res => {
          if (res.code != 0) {
            this.$message.error(res.msg);
          }
          this.isLoading = false;
          return res;
        })
        .catch(res => {
          this.isLoading = false;
          this.$message.error("服务异常");
        });
    },
    submitForm() {
      if (!this._validConditionDesign()) {
        this.$message({
          type: "warning",
          message: "条件有未填写的项目"
        });
        return;
      }

      let {
        ruleId,
        ruleName,
        ruleTypeSelect,
        statusSelect,
        rangeDate,
        ruleGroup,
        description
      } = this.formData;

      let data = {
        ruleId,
        ruleName,
        ruleGroup,
        description,
        ruleType: ruleTypeSelect,
        status: statusSelect,
        startDate: rangeDate[0],
        endDate: rangeDate[1]
      };

      this.$refs["forms"].validate(valid => {
        if (valid) {
          let jsonResultData = this.jsonResultData,
            conditionInfo = this.conditionInfo;

          if (jsonResultData.length == 0) {
            this.$message({
              type: "warning",
              message: "积分及权益设置不能为空"
            });
            return;
          }

          this.$refs["forms2"].validate(valid => {
            if (valid) {
              this.conditionList = this.$refs.conditionPanel.getData();
              if (this.conditionList) {
                let jsonCondition = this.conditionList.filter;
                this.request({
                  ...api.save,
                  data: Object.assign( data, {
                    jsonCondition: JSON.stringify({
                      operator: jsonCondition.operator || "",
                      filter: (() => {
                        const iteration = data => {
                          for (var j = 0; j < data.length; j++) {
                            let o = data[j];
                            if (!o.item) {
                              let result = conditionInfo.find(
                                  item => item.groupName === o.group
                                ),
                                results = result.conditions.find(
                                  item => item.groupId === result.groupId
                                );
                              o.groupId = result.groupId;
                              o.groupName = result.groupName;
                              o.tableName = results.tableName;
                              o.fieldValue = o.tagValue;
                              // o.dataDefine = results.dataDefine;
                              // o.dataDefineDb = results.dataDefineDb;
                              o.dataDefine = o.tagDbDefine;
                              o.dataDefineDb = o.tagDbDefine;
                            }
                            if (o.item != undefined && o.item.length > 0) {
                              iteration(o.item);
                            }
                          }
                        };

                        iteration(jsonCondition.item);

                        return jsonCondition.item || [];
                      })()
                    }),
                    jsonResult: (() => {
                      let fresh = [];
                      if (jsonResultData && jsonResultData.length) {
                        jsonResultData.forEach(item => {
                          item.CUSTOM = [];
                          item.SELECTDATA = {};
                          fresh.push(item);
                        });
                      }
                      return JSON.stringify(fresh);
                    })()
                  })
                }).then(res => {
                  if (res.code === 0) {
                    this.$message.success("保存成功");
                    this.$router.push("/rules/point");
                  }
                });
              }
            }
            return false;
          });
        }
        return false;
      });
    },
    addPointsRow() {
      this.jsonResultData.push({
        fieldName: "",
        fieldValue: "",
        groupId: "",
        groupName: "",
        operation: "",
        pointType: "",
        ratioVal: "",
        roundType: "",
        tableName: "",
        validDateType: "",
        validDateVal: "",
        frozenDays: "",
        SELECTDATA: this.resultInfoData,
        CUSTOM: []
      });
    },
    resultInfoHandler(currentIndex, rowIndex, type) {
      const jsonResultData = this.jsonResultData[rowIndex];
      const resultInfoData = this.resultInfoData;

      switch (type) {
        case "parent":
          if (!currentIndex) {
            [
              "CUSTOM",
              "fieldName",
              "fieldValue",
              "groupId",
              "groupName",
              "operation",
              "ratioVal",
              "pointType",
              "roundType",
              "validDateType",
              "tableName",
              "frozenDays",
              "validDateVal"
            ].forEach(v => {
              this.$set(jsonResultData, v, v === "CUSTOM" ? [] : "");
            });
            return;
          }

          const o = resultInfoData.find(
            items => items.groupId === currentIndex
          );

          jsonResultData.groupName = o.groupName;
          jsonResultData.CUSTOM = o;
          jsonResultData.CUSTOM.validDateTypeText = this._validDateTypeMap(
            o.validDateType
          );
          jsonResultData.validDateType = o.validDateType;
          jsonResultData.validDateVal = o.validDateVal;
          jsonResultData.pointType = o.pointType;
          break;
        case "child":
          if (currentIndex) {
            const o2 = jsonResultData.CUSTOM.conditions.find(
              items => items.fieldValue === currentIndex
            );
            jsonResultData.fieldName = o2.fieldName;
            jsonResultData.tableName = o2.tableName;
          } else {
            jsonResultData.fieldName = "";
            jsonResultData.tableName = "";
          }

          break;
      }
    },
    onError(res) {
      this.$message({
        type: "error",
        message: res.msg
      });
      return false;
    },
    _validConditionDesign() {
      let isValid = true;
      const fn = list => {
        _.each(list, (l, i) => {
          if (l.level == 1) {
            if (
              !l.inputValue ||
              l.secondValue ||
              (l.secondValue && !l.secondValue.length)
            ) {
              isValid = false;
            }
          }
          fn(l.item);
        });
      };
      fn(this.conditionList);
      return isValid;
    },
    _getOptions(dataType, selects) {
      let target = [];
      const convert = list => {
        _.each(list, o => {
          o.label = o.text;
        });
        return list;
      };
      switch (dataType) {
        case "int":
          target = convert(selects.operationNumberSelect);
          break;
        case "list":
          target = convert(selects.operationBoolSelect);
          break;
        case "float":
          target = convert(selects.operationBoolSelect);
          break;
        case "intrange":
          target = convert(selects.operationRangeSelect);
          break;
        case "multiselect":
          target = convert(selects.operationMultiSelect);
          break;
        case "string":
          target = convert(selects.operationStringSelect);
          break;
        case "daterange":
          target = convert(selects.operationRangeSelect);
          break;
        case "date":
        case "datetime":
          target = convert(selects.operationDatetimeSelect);
          break;
      }
      return target;
    },
    _toValiDateNumber(rule, value, fn) {
      if (typeof value === "number" && value >= 0) {
        fn();
      } else {
        fn(new Error("请填写正整数或0"));
      }
    },
    _validDateType(key) {
      const typeMap = {
        1: "mouth",
        2: "year"
      };
      return {
        [`${typeMap[key]}`]: true
      };
    },
    _validDateTypeMap(key) {
      const map = {
        1: "滚动周期",
        2: "自然年"
      };
      return key ? map[key] : "";
    },
    _typeLanguageHandler(type, key) {
      const map = {
        0: "pleaseSelect",
        1: "pleaseFillin"
      };
      return this.$t(map[type]) + this.$t(key);
    },
    _labelLanguageHandler(key) {
      return this.$t(key);
    },
    _currentRouterPage() {
      const route = this.$route,
        signMap = {
          edit: {
            ruleId: route.params.id
          },
          add: {}
        };

      return signMap[this.sign];
    }
  },
  props: ["sign"],
  computed: {
    jsonResultData() {
      return this.pointsRowCacheData.jsonResult;
    },
    resultInfoData() {
      return this.pointsRowCacheData.resultInfo;
    },
    _groupId() {
      let cache = [];
      this.jsonResultData.forEach(item => {
        cache.push(item.groupId);
      });
      return cache;
    },
    _ruleTypeSelect: {
      get() {
        const forms = this.formData,
          o = forms.ruleTypeOption.find(o => o.value == forms.ruleTypeSelect);
        return o ? o.value : "";
      },
      set(v) {
        this.formData.ruleTypeSelect = v;
      }
    },
    _statusSelect: {
      get() {
        const forms = this.formData,
          o = forms.statusOption.find(o => o.value == forms.statusSelect);
        return o ? o.value : "";
      },
      set(v) {
        this.formData.statusSelect = v;
      }
    }
  },
  created() {},
  mounted() {
    const params = this._currentRouterPage();
    const formData = this.formData;

    this.request({
      ...api.detail,
      params
    }).then(res => {
      const data = res.data;

      if (data && JSON.stringify(data) !== "{}") {
        data.tagInfo = (() => {
          const cascadeOptions = [];

          _.each(data.conditionInfo, item => {
            const v = {};
            v.tagTypeId = item.groupId;
            v.tagTypeName = item.groupName;
            v.tags = [];

            console.log("item: ", item);

            _.each(item.conditions, c => {
              console.log("c: ", c);

              const child = {};
              child.tagValue = c.fieldValue;
              child.tagCn = c.fieldName;
              child.tagId = c.id;
              child.tagDsTable = c.tableName;
              child.tagDefine = c.dataDefine;
              child.tagDbDefine = c.dataDefineDb;
              // child.tagValueList = this._getOptions(c.dataDefine, item);
              child.tagValueList = c.configValueList;
              v.tags.push(child);
            });
            cascadeOptions.push(v);
          });

          console.log("cascadeOptions: ", cascadeOptions);

          return cascadeOptions;
        })();

        let jsonCondition = data.jsonCondition
          ? JSON.parse(data.jsonCondition)
          : {};

        data.segmentJson = JSON.stringify({
          filter: {
            operator: jsonCondition.operator || "",
            item: jsonCondition.filter || []
          }
        });

        this.segmentData = data;
        this.conditionInfo = data.conditionInfo;

        // 类型选项
        formData.ruleTypeOption = data.pointRuleTypeSelect;
        // 状态选项
        formData.statusOption = data.statusSelect;

        if (params.ruleId) {
          // 规则ID
          formData.ruleId = data.ruleId;
          // 分类
          formData.ruleGroup = data.ruleGroup;
          // 名称
          formData.ruleName = data.ruleName;
          // 类型
          formData.ruleTypeSelect = data.ruleType;
          // 状态
          formData.statusSelect = data.status;
          // 有效期开始
          formData.rangeDate.push(data.startDate || "");
          // 有效期结束
          formData.rangeDate.push(data.endDate || "");
        }

        // 取舍规则
        formData.roundTypeOptions = data.roundTypeSelect;
        // 运算符
        formData.operationSelect = data.operationSelect;
        // 积分及权益设置
        this.pointsRowCacheData.resultInfo = data.resultInfo || [];

        if (data.jsonResult) {
          let jsonResult = JSON.parse(data.jsonResult);
          jsonResult.forEach(
            (
              {
                fieldValue,
                fieldName,
                groupId,
                groupName,
                operation,
                pointType,
                ratioVal,
                roundType,
                tableName,
                validDateType,
                validDateVal,
                frozenDays = ""
              },
              idx
            ) => {
              const conditions = this.resultInfoData.find(
                items => items.groupId === groupId
              );

              this.jsonResultData.push({
                fieldValue,
                fieldName,
                groupId,
                groupName,
                operation,
                pointType,
                ratioVal,
                roundType,
                tableName,
                validDateType,
                validDateVal,
                frozenDays,
                SELECTDATA: this.resultInfoData,
                CUSTOM: conditions
                  ? (() => {
                      conditions.validDateTypeText = this._validDateTypeMap(
                        conditions.validDateType
                      );
                      return conditions;
                    })()
                  : []
              });
            }
          );
        }
      }
    });
  },
  components: {
    aConditionPanel,
    CommonForm
  }
};
</script>

<style lang="scss">
@import "../../../../styles/points-edit.scss";
</style>